package com.cecbridge.remotev2;
public class GeometryTest {
 public static void main(String[] args){
  int cases=0; float minGap=Float.MAX_VALUE;
  for(int w=160;w<=560;w+=10)for(int h=160;h<=560;h+=10)for(float density:new float[]{1,1.5f,2,2.5f,3}){
    float inset=2*density;
    RoundPanelGeometry g=new RoundPanelGeometry(w,h,inset,inset);
    for(int i=0;i<g.x.length;i++){
      double d=Math.hypot(g.x[i]-g.cx,g.y[i]-g.cy);
      if(d+g.key>g.screenRadius+.001 || d-g.key<g.wheel+inset-.001)throw new AssertionError("radial");
      if(g.hitKey(g.x[i],g.y[i])!=i||g.hitWheel(g.x[i],g.y[i])!=0)throw new AssertionError("hit key");
      for(int j=i+1;j<g.x.length;j++){
        float gap=(float)Math.hypot(g.x[i]-g.x[j],g.y[i]-g.y[j])-2*g.key;
        if(gap<inset-.001)throw new AssertionError("collision "+gap);
        minGap=Math.min(minGap,gap);
      }
    }
    float m=(g.wheel+g.ok)/2;
    if(g.hitWheel(g.cx,g.cy)!=1||g.hitWheel(g.cx,g.cy-m)!=2||g.hitWheel(g.cx,g.cy+m)!=3||g.hitWheel(g.cx-m,g.cy)!=4||g.hitWheel(g.cx+m,g.cy)!=5||g.hitKey(g.cx,g.cy)!=-1)throw new AssertionError("D-pad");
    cases++;
  }
  System.out.println("Geometry checks passed: "+cases+" cases; minimum inter-key gap "+minGap+" px");
  for(int d:new int[]{192,200,220,240}){
    RoundPanelGeometry g=new RoundPanelGeometry(d,d,2,2);
    System.out.printf("%d dp: wheel %.2f, center %.2f, peripheral %.2f dp diameters%n",d,g.wheel*2,g.ok*2,g.key*2);
  }
 }
}
