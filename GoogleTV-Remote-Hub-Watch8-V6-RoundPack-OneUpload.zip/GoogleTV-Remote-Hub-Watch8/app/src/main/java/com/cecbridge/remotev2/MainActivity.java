package com.cecbridge.remotev2;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.graphics.drawable.Icon;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.wifi.WifiManager;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.WindowManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Independent Wear OS client: Google TV Remote v2, no TV APK or phone relay. */
public final class MainActivity extends Activity {
    private static final int BG=0xff08090b, PANEL=0xff181b20, LIGHT=0xfff5f7fa,
            SUB=0xffaab2bd, ACCENT=0xff62d0c0, GREEN=0xff176657, RED=0xff713744;
    private static final String PREFS="google_tv_remote_v2"; // keep V3 pairing data
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private final List<SavedApp> savedApps=new ArrayList<>();
    private SharedPreferences prefs;
    private EditText hostField, pinField;
    private TextView statusView;
    private LinearLayout appsGrid;
    private Button launchModeButton;
    private IdentityStore identity;
    private PairingClient pairing;
    private RemoteSession remote;
    private NsdManager nsd;
    private NsdManager.DiscoveryListener discovery;
    private WifiManager.MulticastLock multicastLock;
    private RoundPanelView panel;
    private int currentPage;
    private int controlHeight=40;
    public static final String EXTRA_OPEN_PAGE="com.cecbridge.remotev2.extra.OPEN_PAGE";
    private boolean compactDisplay;
    private AlertDialog settingsDialog;
    private String lastStatus="正在初始化…";
    private boolean lastError;
    private Boolean tvPower;
    private TextView powerView;
    private AlertDialog appsDialog;
    private volatile boolean resolving;

    private static final class SavedApp {
        String name, target;
        SavedApp(String n,String t){name=n;target=t;}
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        int heightDp=Math.round(getResources().getDisplayMetrics().heightPixels/getResources().getDisplayMetrics().density);
        compactDisplay=heightDp<315;
        controlHeight=Math.max(31,Math.min(39,Math.round(heightDp*0.14f)));
        prefs=getSharedPreferences(PREFS,MODE_PRIVATE);
        restoreApps();
        disableLegacyShortcuts();
        openRequestedPage(getIntent());
        io.execute(() -> {
            try {
                identity=new IdentityStore(getApplicationContext());
                remote=createRemote();
                String host=prefs.getString("host", "");
                if(!host.isEmpty()&&!prefs.getString("tv_fingerprint", "").isEmpty())
                    connectInternal(host);
                else showStatus("首次使用：点击顶部设置，连接并配对电视",false);
            } catch(Exception e) { showStatus("初始化失败："+e.getMessage(),true); }
        });
    }

    private RemoteSession createRemote(){
        return new RemoteSession(identity,new RemoteSession.Listener(){
            @Override public void status(String s){showStatus(s,false);}
            @Override public void powerState(Boolean on){
                runOnUiThread(() -> {
                    tvPower=on;
                    if(powerView!=null)powerView.setText(powerText());
                    if(panel!=null)panel.invalidate();
                });
            }
        });
    }

    /** Each launcher creates exactly one full-screen panel. No pager or hidden pages. */
    private void buildPanel(int page){
        currentPage=page==1?1:0;
        panel=new RoundPanelView(currentPage==1);
        panel.setBackgroundColor(BG);
        setContentView(panel);
    }

    private void showSettings(){
        if(settingsDialog!=null&&settingsDialog.isShowing())return;
        ScrollView scroll=new ScrollView(this);
        LinearLayout p=new LinearLayout(this);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setPadding(dp(12),dp(4),dp(12),dp(8));
        scroll.addView(p);
        statusView=smallNote(lastStatus);
        statusView.setTextColor(lastError?0xffffa3aa:ACCENT);
        p.addView(statusView);
        powerView=smallNote(powerText());p.addView(powerView);gap(p,5);
        connectionPage(p);
        gap(p,9);
        pairingPage(p);
        gap(p,9);
        launchModeButton=button(p,"",GREEN,0,this::cyclePlayMode);
        refreshPlayModeText();gap(p,5);
        button(p,"自定义电视 App",PANEL,0,this::showApps);
        gap(p,5);
        button(p,"固定遥控快捷方式",PANEL,0,()->pinPanelShortcut(0,"tv-remote-panel","TV 遥控",R.drawable.ic_panel_remote));
        gap(p,5);
        button(p,"固定媒体快捷方式",PANEL,0,()->pinPanelShortcut(1,"tv-media-panel","TV 媒体",R.drawable.ic_panel_media));
        gap(p,5);
        p.addView(smallNote("配对信息留在手表。自动确认可能误触电视按钮，建议手动确认。"));
        settingsDialog=new AlertDialog.Builder(this).setTitle("电视设置").setView(scroll)
                .setPositiveButton("关闭",null).create();
        settingsDialog.setOnDismissListener(d->{settingsDialog=null;hostField=null;pinField=null;statusView=null;powerView=null;launchModeButton=null;});
        settingsDialog.show();
    }
    private String powerText(){return tvPower==null?"电视电源状态未知":tvPower?"电视正在运行":"电视待机";}
    private void showApps(){
        ScrollView scroll=new ScrollView(this);
        LinearLayout p=new LinearLayout(this);p.setOrientation(LinearLayout.VERTICAL);
        p.setPadding(dp(10),dp(4),dp(10),dp(8));scroll.addView(p);
        appsPage(p);
        appsDialog=new AlertDialog.Builder(this).setTitle("电视 App").setView(scroll).setPositiveButton("关闭",null).create();
        appsDialog.setOnDismissListener(d->{appsGrid=null;appsDialog=null;});appsDialog.show();
    }

    /**
     * Canvas layout uses the full round watch area. Each radial cell has its own
     * non-overlapping hit region. Only ACTION_UP fires a command; swipes are ignored.
     */
    private final class RoundPanelView extends View {
        private static final int POWER=1, VOL_DOWN=2, VOL_UP=3,
                BOTTOM_LEFT=4, BOTTOM_MIDDLE=5, BOTTOM_RIGHT=6,
                OK=7, UP=8, DOWN=9, LEFT=10, RIGHT=11,
                REWIND=12, FORWARD=13, STATUS=15,
                YOUTUBE=16, NETFLIX=17;
        private final boolean media;
        private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF bounds=new RectF();
        private boolean navigationMode;
        private int pressed, startTarget;
        private float startX,startY;
        private RoundPanelGeometry geometry;
        private final Path triangle=new Path();
        // Slots follow the screen circumference, clockwise from upper left.
        private final int[] slots;
        private int geometryWidth=-1,geometryHeight=-1;

        RoundPanelView(boolean forMedia){
            super(MainActivity.this);
            media=forMedia;
            slots=new int[]{POWER,STATUS,VOL_DOWN,VOL_UP,
                    media?FORWARD:NETFLIX,BOTTOM_RIGHT,BOTTOM_MIDDLE,BOTTOM_LEFT,
                    media?REWIND:YOUTUBE};
            setContentDescription(media?"媒体面板：中间确定，圆环媒体操作，右下切换方向键，左上设置":"电视遥控：中间确定，圆环方向键，左上设置");
            setClickable(true);
        }

        private void computeGeometry(){
            int w=getWidth(),h=getHeight();
            if(geometry==null||w!=geometryWidth||h!=geometryHeight){
                geometryWidth=w;geometryHeight=h;
                geometry=new RoundPanelGeometry(w,h,Math.max(dp(2),1),Math.max(dp(2),1));
            }
        }

        @Override protected void onDraw(Canvas c){
            super.onDraw(c);
            computeGeometry();
            RoundPanelGeometry g=geometry;
            if(g.wheel<=0)return;
            float cx=g.cx,cy=g.cy,wheelRadius=g.wheel;
            // The entire annulus is clickable: four large directional sectors.
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(0xff292f36);
            c.drawCircle(cx,cy,wheelRadius,paint);
            if(pressed>=UP && pressed<=RIGHT){
                int angle=pressed==RIGHT?-45:pressed==DOWN?45:pressed==LEFT?135:225;
                paint.setColor(0xff41574f);
                bounds.set(cx-wheelRadius,cy-wheelRadius,cx+wheelRadius,cy+wheelRadius);
                c.drawArc(bounds,angle,90,true,paint);
            }
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(1));
            paint.setColor(0xff424a54);
            c.drawCircle(cx,cy,wheelRadius,paint);
            for(int deg=45;deg<360;deg+=90){
                double rad=Math.toRadians(deg);
                float cos=(float)Math.cos(rad),sin=(float)Math.sin(rad);
                c.drawLine(cx+g.ok*cos,cy+g.ok*sin,
                        cx+wheelRadius*.98f*cos,cy+wheelRadius*.98f*sin,paint);
            }
            paint.setStyle(Paint.Style.FILL);
            float offset=(wheelRadius+g.ok)*.5f;
            if(media&&!navigationMode){
                drawMediaGlyph(c,cx,cy-offset,wheelRadius*.30f,UP);
                drawMediaGlyph(c,cx,cy+offset,wheelRadius*.30f,DOWN);
                drawMediaGlyph(c,cx-offset,cy,wheelRadius*.30f,LEFT);
                drawMediaGlyph(c,cx+offset,cy,wheelRadius*.30f,RIGHT);
            }else{
                drawArrow(c,cx,cy-offset,wheelRadius*.37f,0);
                drawArrow(c,cx,cy+offset,wheelRadius*.37f,180);
                drawArrow(c,cx-offset,cy,wheelRadius*.37f,270);
                drawArrow(c,cx+offset,cy,wheelRadius*.37f,90);
            }
            paint.setColor(pressed==OK?0xff657c78:0xff586269);
            c.drawCircle(cx,cy,g.ok,paint);
            paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(1));
            paint.setColor(0xff708087);c.drawCircle(cx,cy,g.ok,paint);
            drawFittedText(c,"确定",cx,cy,g.ok*1.6f,g.ok*.69f,LIGHT);

            // The same geometry is used for drawing AND hit-testing all small circles.
            for(int i=0;i<slots.length;i++){
                int id=slots[i];
                float x=g.x[i],y=g.y[i],r=g.key;
                switch(id){
                    case POWER: drawCircleKey(c,x,y,r,"",id,GREEN);drawPower(c,x,y,r);break;
                    case STATUS: drawCircleKey(c,x,y,r,"设置",id,lastError?RED:PANEL);break;
                    case VOL_DOWN:drawCircleKey(c,x,y,r,"音−",id,PANEL);break;
                    case VOL_UP:drawCircleKey(c,x,y,r,"音+",id,PANEL);break;
                    case YOUTUBE:drawCircleKey(c,x,y,r,"YT",id,0xffb51c27);break;
                    case NETFLIX:drawCircleKey(c,x,y,r,"N",id,0xff26262a);break;
                    case REWIND:drawCircleKey(c,x,y,r,"",id,PANEL);drawSeek(c,x,y,r,false);break;
                    case FORWARD:drawCircleKey(c,x,y,r,"",id,PANEL);drawSeek(c,x,y,r,true);break;
                    case BOTTOM_LEFT:drawCircleKey(c,x,y,r,media?"Kodi":"返回",id,media?GREEN:PANEL);break;
                    case BOTTOM_MIDDLE:drawCircleKey(c,x,y,r,media?"Qobuz":"菜单",id,media?GREEN:PANEL);break;
                    case BOTTOM_RIGHT:drawCircleKey(c,x,y,r,media?(navigationMode?"播放":"方向"):"主页",id,media?PANEL:GREEN);break;
                }
            }
        }

        private void drawFittedText(Canvas c,String value,float x,float y,float maxWidth,float size,int color){
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(color);
            paint.setTypeface(Typeface.DEFAULT_BOLD);
            paint.setTextSize(size);
            float measured=paint.measureText(value);
            if(measured>maxWidth)paint.setTextSize(size*maxWidth/measured);
            paint.setTextAlign(Paint.Align.CENTER);
            Paint.FontMetrics fm=paint.getFontMetrics();
            c.drawText(value,x,y-(fm.ascent+fm.descent)/2f,paint);
        }

        private void drawCircleKey(Canvas c,float x,float y,float r,String txt,int id,int color){
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(pressed==id?0xff527a70:color);
            c.drawCircle(x,y,r,paint);
            paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(1));
            paint.setColor(0xff3e4b4c);c.drawCircle(x,y,r,paint);
            if(!txt.isEmpty())drawFittedText(c,txt,x,y,r*1.67f,r*(id==NETFLIX?.98f:.76f),LIGHT);
        }

        private void drawArrow(Canvas c,float x,float y,float size,float angle){
            paint.setStyle(Paint.Style.FILL);paint.setColor(LIGHT);
            c.save();c.translate(x,y);c.rotate(angle);
            triangle.reset();triangle.moveTo(0,-size*.48f);
            triangle.lineTo(size*.5f,size*.38f);triangle.lineTo(-size*.5f,size*.38f);
            triangle.close();c.drawPath(triangle,paint);c.restore();
        }

        private void drawPower(Canvas c,float x,float y,float r){
            paint.setColor(LIGHT);paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeCap(Paint.Cap.ROUND);paint.setStrokeWidth(r*.12f);
            float a=r*.43f;
            c.drawArc(x-a,y-a,x+a,y+a,-50,280,false,paint);
            c.drawLine(x,y-r*.57f,x,y-r*.06f,paint);
            paint.setStrokeCap(Paint.Cap.BUTT);paint.setStyle(Paint.Style.FILL);
        }

        private void drawSeek(Canvas c,float x,float y,float r,boolean forward){
            float angle=forward?90:270;
            drawArrow(c,x-r*.28f,y,r*.61f,angle);
            drawArrow(c,x+r*.28f,y,r*.61f,angle);
        }

        private void drawMediaGlyph(Canvas c,float x,float y,float size,int target){
            paint.setStyle(Paint.Style.FILL);paint.setColor(LIGHT);
            float h=size*.40f;
            if(target==UP){
                drawArrow(c,x-size*.28f,y,size*.68f,90);
                c.drawRect(x+size*.12f,y-h,x+size*.25f,y+h,paint);
                c.drawRect(x+size*.36f,y-h,x+size*.49f,y+h,paint);
            }else if(target==DOWN){
                c.drawRect(x-h,y-h,x+h,y+h,paint);
            }else{
                boolean next=target==RIGHT;
                float d=next?1:-1;
                drawArrow(c,x-d*size*.10f,y,size*.84f,next?90:270);
                float bar=x+d*size*.43f;
                c.drawRect(bar-size*.065f,y-h,bar+size*.065f,y+h,paint);
            }
        }

        private int hit(float x,float y){
            computeGeometry();
            int slot=geometry.hitKey(x,y);
            if(slot>=0)return slots[slot];
            switch(geometry.hitWheel(x,y)){
                case 1:return OK;
                case 2:return UP;
                case 3:return DOWN;
                case 4:return LEFT;
                case 5:return RIGHT;
                default:return 0;
            }
        }

        @Override public boolean onTouchEvent(MotionEvent e){
            switch(e.getActionMasked()){
                case MotionEvent.ACTION_DOWN:
                    startX=e.getX();startY=e.getY();
                    startTarget=hit(startX,startY);
                    pressed=startTarget;
                    invalidate();return true;
                case MotionEvent.ACTION_MOVE:
                    if(Math.hypot(e.getX()-startX,e.getY()-startY)>dp(15)){
                        if(pressed!=0){pressed=0;invalidate();}
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    int end=hit(e.getX(),e.getY());
                    int perform=startTarget==end &&
                            Math.hypot(e.getX()-startX,e.getY()-startY)<dp(17)?end:0;
                    pressed=0;startTarget=0;invalidate();
                    if(perform!=0){performClick();onKeySelected(perform);}
                    return true;
                case MotionEvent.ACTION_CANCEL:
                    pressed=0;startTarget=0;invalidate();return true;
            }
            return true;
        }

        @Override public boolean performClick(){super.performClick();return true;}

        private void onKeySelected(int target){
            switch(target){
                case POWER:key(26,"电源切换");return;
                case VOL_DOWN:key(25,"音量减");return;
                case VOL_UP:key(24,"音量加");return;
                case STATUS:
                    showSettings();return;
                case OK:key(23,"确定");return;
                case REWIND:key(89,"快退");return;
                case FORWARD:key(90,"快进");return;
                case YOUTUBE:
                    launchViaPlay(new SavedApp("YouTube","com.google.android.youtube.tv"));return;
                case NETFLIX:
                    launchViaPlay(new SavedApp("Netflix","com.netflix.ninja"));return;
            }
            if(media){
                if(target==BOTTOM_LEFT){launchViaPlay(new SavedApp("Kodi","org.xbmc.kodi"));return;}
                if(target==BOTTOM_MIDDLE){launchViaPlay(new SavedApp("Qobuz","com.qobuz.music"));return;}
                if(target==BOTTOM_RIGHT){navigationMode=!navigationMode;invalidate();return;}
                if(!navigationMode){
                    switch(target){
                        case UP:key(85,"播放/暂停");return;
                        case DOWN:key(86,"停止播放");return;
                        case LEFT:key(88,"上一个");return;
                        case RIGHT:key(87,"下一个");return;
                    }
                }
            }else{
                if(target==BOTTOM_LEFT){key(4,"返回");return;}
                if(target==BOTTOM_MIDDLE){key(82,"菜单");return;}
                if(target==BOTTOM_RIGHT){key(3,"主页");return;}
            }
            switch(target){
                case UP:key(19,"向上");break;
                case DOWN:key(20,"向下");break;
                case LEFT:key(21,"向左");break;
                case RIGHT:key(22,"向右");break;
            }
        }
    }

    private void appsPage(LinearLayout p){
        p.addView(smallNote("点击启动 · 长按编辑 / 删除"));
        gap(p,6);
        appsGrid=new LinearLayout(this);
        appsGrid.setOrientation(LinearLayout.VERTICAL);
        p.addView(appsGrid);
        renderApps();
        gap(p,6);
        button(p,"＋ 添加电视 App",PANEL,0,()->editApp(-1));
        gap(p,5);
        p.addView(smallNote("由电视 Google Play 启动；启动模式在顶部设置。"));
    }

    private void connectionPage(LinearLayout p){
        p.addView(smallNote("手表与电视必须位于可互通的局域网"));
        gap(p,7);
        hostField=input("电视 IP / 主机名",prefs.getString("host",""),
                InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_URI);
        p.addView(hostField);
        gap(p,8);
        LinearLayout buttons=row(p);
        button(buttons,"搜索电视",PANEL,1,this::startDiscovery);
        button(buttons,"连接电视",GREEN,1,this::connect);
        gap(p,8);
        p.addView(smallNote("搜索不到时，输入电视的 IPv4 地址。蓝牙代理网络不一定支持局域网访问。"));
    }

    private void pairingPage(LinearLayout p){
        p.addView(smallNote("先点首次配对，再看电视上的六位配对码"));
        gap(p,7);
        button(p,"① 请求电视显示配对码",PANEL,0,this::startPair);
        gap(p,8);
        pinField=input("六位配对码", "",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        p.addView(pinField);
        gap(p,8);
        button(p,"② 确认配对并连接",GREEN,0,this::finishPair);
        gap(p,7);
        button(p,"忘记这台电视的配对",RED,0,()->new AlertDialog.Builder(this)
                .setTitle("清除配对？").setMessage("清除后需要重新从电视获取六位验证码。")
                .setNegativeButton("取消",null).setPositiveButton("清除",(d,w)->forgetPair()).show());
        gap(p,6);
        p.addView(smallNote("配对证书仅保存在这块手表上。"));
    }

    private TextView smallNote(String s){
        TextView t=label(s,11,SUB,false);t.setGravity(Gravity.CENTER);
        t.setPadding(dp(2),dp(2),dp(2),dp(2));return t;
    }
    /** Legacy launcher pins remain owned by the user; mark old wake/sleep pins disabled. */
    private void disableLegacyShortcuts(){
        try{
            ShortcutManager shortcuts=getSystemService(ShortcutManager.class);
            if(shortcuts!=null)shortcuts.disableShortcuts(
                    java.util.Arrays.asList("tv-wake","tv-sleep","tv-toggle"),"旧版快捷方式已停用，请在桌面删除");
        }catch(Exception ignored){}
    }

    private int playMode(){return prefs.getInt("play_mode_v42",2);}
    private void cyclePlayMode(){
        int next=playMode()==2?1:playMode()==1?0:2;
        prefs.edit().putInt("play_mode_v42",next).apply();
        refreshPlayModeText();
    }
    private void refreshPlayModeText(){
        if(launchModeButton==null)return;
        int mode=playMode();
        String text=mode==0?"启动方式：Play 直启尝试":
                mode==1?"启动方式：详情页 + 自动按确定":"启动方式：详情页 + 手动确认";
        launchModeButton.setText(text+"  ↻");
    }

    private void restoreApps(){
        String saved=prefs.getString("custom_tv_apps_v4",null);
        if(saved==null){
            savedApps.add(new SavedApp("Kodi","org.xbmc.kodi"));
            savedApps.add(new SavedApp("Qobuz","com.qobuz.music"));
            return;
        }
        try{
            JSONArray array=new JSONArray(saved);
            for(int i=0;i<array.length();i++){
                JSONObject obj=array.getJSONObject(i);
                String name=obj.optString("name","").trim();
                String target=obj.optString("target","").trim();
                if(!name.isEmpty()&&!target.isEmpty())savedApps.add(new SavedApp(name,target));
            }
        }catch(Exception ignored){
            savedApps.clear();
            savedApps.add(new SavedApp("Kodi","org.xbmc.kodi"));
            savedApps.add(new SavedApp("Qobuz","com.qobuz.music"));
        }
    }
    private void persistApps(){
        JSONArray json=new JSONArray();
        for(SavedApp a:savedApps){
            JSONObject o=new JSONObject();
            try{o.put("name",a.name);o.put("target",a.target);}catch(Exception ignored){}
            json.put(o);
        }
        prefs.edit().putString("custom_tv_apps_v4",json.toString()).apply();
    }
    private void renderApps(){
        if(appsGrid==null)return;
        appsGrid.removeAllViews();
        for(int i=0;i<savedApps.size();i+=2){
            LinearLayout r=row(appsGrid);
            for(int j=i;j<Math.min(i+2,savedApps.size());j++){
                final int at=j;
                SavedApp item=savedApps.get(j);
                Button btn=button(r,item.name,at<2?GREEN:PANEL,1,()->{launchViaPlay(item);if(appsDialog!=null)appsDialog.dismiss();if(settingsDialog!=null)settingsDialog.dismiss();});
                btn.setOnLongClickListener(v->{editApp(at);return true;});
            }
            if(i+1>=savedApps.size())spacerButton(r);
            gap(appsGrid,9);
        }
        if(savedApps.isEmpty())appsGrid.addView(label("还没有快捷 App，点击下方添加。",12,SUB,false));
    }
    private void editApp(int index){
        boolean editing=index>=0&&index<savedApps.size();
        if(editing){
            SavedApp current=savedApps.get(index);
            new AlertDialog.Builder(this).setTitle(current.name)
                    .setItems(new String[]{"修改名称或包名","删除此快捷方式","取消"},(d,which)->{
                        if(which==0)promptAppName(index);
                        else if(which==1)new AlertDialog.Builder(this).setTitle("删除「"+current.name+"」？")
                                .setNegativeButton("取消",null)
                                .setPositiveButton("删除",(dialog,button)->{
                                    savedApps.remove(index);persistApps();renderApps();
                                }).show();
                    }).show();
        }else promptAppName(-1);
    }
    private void promptAppName(int index){
        boolean editing=index>=0 && index<savedApps.size();
        String existing=editing?savedApps.get(index).name:"";
        EditText field=input("快捷名称，如 MX Player",existing,InputType.TYPE_CLASS_TEXT);
        new AlertDialog.Builder(this).setTitle("电视 App 名称")
                .setView(dialogInput(field)).setNegativeButton("取消",null)
                .setPositiveButton("下一步",(d,w)->{
                    String name=field.getText().toString().trim();
                    if(name.isEmpty() || name.length()>32){showStatus("名称为 1–32 个字符，请重新填写",true);return;}
                    promptAppPackage(index,name);
                }).show();
    }
    private void promptAppPackage(int index,String name){
        boolean editing=index>=0 && index<savedApps.size();
        String existing=editing?savedApps.get(index).target:"";
        EditText field=input("如 com.qobuz.music",existing,InputType.TYPE_CLASS_TEXT);
        new AlertDialog.Builder(this).setTitle("Android 包名")
                .setView(dialogInput(field)).setNegativeButton("取消",null)
                .setPositiveButton("保存",(d,w)->{
                    String target=field.getText().toString().trim();
                    if(!validTarget(target)){showStatus("无效的 Android 包名，请重新编辑",true);return;}
                    if(editing){SavedApp app=savedApps.get(index);app.name=name;app.target=target;}
                    else savedApps.add(new SavedApp(name,target));
                    persistApps();renderApps();
                    showStatus("已保存电视 App："+name,false);
                }).show();
    }
    private LinearLayout dialogInput(EditText field){
        LinearLayout wrapper=new LinearLayout(this);
        wrapper.setPadding(dp(12),dp(8),dp(12),dp(8));wrapper.addView(field);
        return wrapper;
    }

    private void openRequestedPage(Intent intent){
        int requested=intent==null?0:intent.getIntExtra(EXTRA_OPEN_PAGE,0);
        // Also accept old pinned shortcuts even if their launcher stripped extras.
        if(intent!=null&&"com.cecbridge.remotev2.action.OPEN_PANEL_1".equals(intent.getAction()))requested=1;
        if(panel==null||currentPage!=(requested==1?1:0))buildPanel(requested);
    }
    @Override protected void onNewIntent(Intent intent){
        super.onNewIntent(intent);
        setIntent(intent);
        if(appsDialog!=null)appsDialog.dismiss();
        if(settingsDialog!=null)settingsDialog.dismiss();
        openRequestedPage(intent);
    }

    private void pinPanelShortcut(int page,String id,String name,int iconId){
        ShortcutManager manager=getSystemService(ShortcutManager.class);
        if(manager==null||!manager.isRequestPinShortcutSupported()){
            showStatus("启动器不支持固定快捷方式；请在表盘快捷方式中直接选择「"+name+"」应用入口。",true);
            return;
        }
        Intent intent=new Intent(this,page==0?RemotePanelLauncherActivity.class:MediaPanelLauncherActivity.class);
        intent.setAction("com.cecbridge.remotev2.action.OPEN_PANEL_"+page);
        intent.putExtra(EXTRA_OPEN_PAGE,page);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        ShortcutInfo shortcut=new ShortcutInfo.Builder(this,id)
                .setShortLabel(name).setLongLabel(name+"（Google TV）")
                .setIcon(Icon.createWithResource(this,iconId)).setIntent(intent).build();
        try{
            if(manager.requestPinShortcut(shortcut,null))showStatus("已请求固定「"+name+"」，请查看手表启动器确认。",false);
            else showStatus("启动器未接受固定快捷方式；仍可选用独立应用入口。",true);
        }catch(Exception e){showStatus("固定快捷方式失败："+e.getMessage(),true);}
    }

    private static boolean validTarget(String raw){
        return raw!=null && raw.length()<=150 &&
                raw.matches("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+");
    }

    /** One tap launches via Google Play. Modes are explicitly chosen by user.
     *  In auto mode a delayed DPAD_CENTER may activate the wrong Play control.
     */
    private void launchViaPlay(SavedApp app){
        if(!validTarget(app.target)){
            showStatus("「"+app.name+"」不是有效包名。请长按修改成 Android 包名。",true);return;
        }
        String host=saveHost();if(host==null)return;
        final int mode=playMode();
        io.execute(()->{
            try{
                ensureConnected(host);
                if(mode==0){
                    remote.launchApp(app.target);
                    showStatus("已尝试通过 Google Play 一键启动「"+app.name+"」。若只出现商店，请切换到自动确认模式。",false);
                }else{
                    remote.openAppStorePage(app.target);
                    if(mode==1){
                        // Give the TV Play Store time to show the details screen.
                        // No foreground/focus telemetry: this is opt-in only.
                        Thread.sleep(1900);
                        remote.sendKey(23);
                        showStatus("已发送「"+app.name+"」Play 详情页与自动确定指令。请检查电视是否真正打开 App。",false);
                    }else{
                        showStatus("已请求打开电视 Google Play 的「"+app.name+"」详情页，可按当前面板中央“确定”。",false);
                    }
                }
            }catch(InterruptedException e){
                Thread.currentThread().interrupt();showStatus("启动操作已中断",true);
            }catch(Exception e){showStatus("Google Play 启动请求失败："+e.getMessage(),true);}
        });
    }

    private void key(int code,String name){
        String host=saveHost();if(host==null)return;
        io.execute(()->{
            try{
                ensureConnected(host);
                remote.sendKey(code);
                showStatus("已发送「"+name+"」。具体响应由电视和当前播放器决定。",false);
            }catch(Exception e){showStatus("发送「"+name+"」失败："+e.getMessage(),true);}
        });
    }
    private String saveHost(){
        String host=(hostField==null?prefs.getString("host",""):hostField.getText().toString()).trim();
        if(host.isEmpty()||host.contains("://")||host.contains("/")||host.contains(" ")||host.contains(":")){
            showStatus("请点顶部设置，输入 Google TV 的 IPv4 地址或主机名",true);return null;
        }
        prefs.edit().putString("host",host).apply();return host;
    }
    private void ensureConnected(String host)throws Exception{
        if(remote==null||identity==null)throw new IllegalStateException("遥控器尚未初始化");
        if(!remote.isReady()){
            String fp=prefs.getString("tv_fingerprint","");
            if(fp.isEmpty())throw new IllegalStateException("请先完成六位码配对");
            remote.connect(host,fp);
        }
    }
    private void connect(){String host=saveHost();if(host!=null)io.execute(()->connectInternal(host));}
    private void connectInternal(String host){
        if(identity==null){showStatus("证书尚未初始化",true);return;}
        try{
            String fp=prefs.getString("tv_fingerprint","");
            if(fp.isEmpty())throw new IllegalStateException("未配对，请先输入电视显示的六位代码");
            showStatus("正在连接 Google TV："+host,false);
            remote.connect(host,fp);
            showStatus("已连接 Google TV，可以操作本机电源、启动 App 和媒体控制。",false);
        }catch(Exception e){showStatus("连接失败："+e.getMessage(),true);}
    }
    private void startPair(){
        String host=saveHost();if(host==null)return;
        io.execute(()->{
            try{
                if(identity==null)throw new IllegalStateException("证书尚未初始化");
                if(pairing!=null)pairing.close();
                if(remote!=null)remote.close();
                pairing=new PairingClient(identity);
                showStatus("请求电视显示六位配对码…",false);
                pairing.begin(host);
                showStatus("请将 Google TV 上显示的六位代码填入下方。",false);
            }catch(Exception e){showStatus("开始配对失败："+e.getMessage(),true);}
        });
    }
    private void finishPair(){
        String pin=pinField.getText().toString().trim();
        String host=saveHost();if(host==null)return;
        if(!pin.matches("(?i)[0-9a-f]{6}")){showStatus("请输入 6 位配对码（0–9 或 A–F）",true);return;}
        io.execute(()->{
            try{
                if(pairing==null)throw new IllegalStateException("请先点击首次配对");
                String fp=pairing.finish(pin);
                prefs.edit().putString("tv_fingerprint",fp).apply();
                runOnUiThread(()->{if(pinField!=null)pinField.setText("");});
                showStatus("配对成功，正在连接…",false);
                connectInternal(host);
            }catch(Exception e){showStatus("配对失败："+e.getMessage()+"，可以重新开始配对。",true);}
        });
    }
    private void forgetPair(){
        io.execute(()->{
            if(pairing!=null)pairing.close();
            if(remote!=null)remote.close();
            prefs.edit().remove("tv_fingerprint").apply();
            showStatus("本机配对记录已清除；再次连接需重新输入配对码。",false);
        });
    }
    private void startDiscovery(){
        try{
            if(discovery!=null){showStatus("正在搜索电视…",false);return;}
            nsd=(NsdManager)getSystemService(Context.NSD_SERVICE);
            try{
                WifiManager wifi=(WifiManager)getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                if(wifi!=null){
                    multicastLock=wifi.createMulticastLock("google-tv-watch-discovery");
                    multicastLock.setReferenceCounted(false);multicastLock.acquire();
                }
            }catch(Exception ignored){}
            discovery=new NsdManager.DiscoveryListener(){
                @Override public void onDiscoveryStarted(String type){showStatus("局域网搜索中…",false);}
                @Override public void onServiceFound(NsdServiceInfo service){
                    if(resolving)return;
                    resolving=true;
                    try{nsd.resolveService(service,new NsdManager.ResolveListener(){
                        @Override public void onServiceResolved(NsdServiceInfo found){
                            resolving=false;
                            if(found.getHost()==null)return;
                            String ip=found.getHost().getHostAddress();
                            runOnUiThread(()->{
                                if(hostField!=null)hostField.setText(ip);prefs.edit().putString("host",ip).apply();
                                showStatus("找到电视："+found.getServiceName()+" · "+ip,false);
                            });stopDiscovery();
                        }
                        @Override public void onResolveFailed(NsdServiceInfo i,int err){
                            resolving=false;showStatus("发现设备，但解析失败（"+err+"），请手动填写 IP",true);
                        }
                    });}catch(Exception ex){resolving=false;showStatus("搜索异常："+ex.getMessage(),true);}
                }
                @Override public void onServiceLost(NsdServiceInfo service){}
                @Override public void onDiscoveryStopped(String type){}
                @Override public void onStartDiscoveryFailed(String type,int err){
                    showStatus("搜索失败（"+err+"），可手动输入 IP",true);stopDiscovery();
                }
                @Override public void onStopDiscoveryFailed(String type,int err){}
            };
            nsd.discoverServices("_androidtvremote2._tcp.",NsdManager.PROTOCOL_DNS_SD,discovery);
        }catch(Exception e){discovery=null;showStatus("无法搜索："+e.getMessage(),true);}
    }
    private void stopDiscovery(){
        NsdManager.DiscoveryListener d=discovery;discovery=null;
        if(nsd!=null&&d!=null)try{nsd.stopServiceDiscovery(d);}catch(Exception ignored){}
        if(multicastLock!=null){try{if(multicastLock.isHeld())multicastLock.release();}catch(Exception ignored){}multicastLock=null;}
    }
    private void showStatus(String text,boolean error){
        runOnUiThread(()->{
            if(isFinishing()||isDestroyed())return;
            lastStatus=text;lastError=error;
            if(statusView!=null){statusView.setText(text);statusView.setTextColor(error?0xffffa3aa:ACCENT);}
            if(error && (settingsDialog==null||!settingsDialog.isShowing()))Toast.makeText(this,text,Toast.LENGTH_SHORT).show();
            if(panel!=null)panel.invalidate();
        });
    }

    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private TextView label(String s,int size,int color,boolean bold){
        TextView t=new TextView(this);t.setText(s);t.setTextColor(color);t.setTextSize(size);
        t.setTypeface(Typeface.DEFAULT,bold?Typeface.BOLD:Typeface.NORMAL);
        t.setGravity(Gravity.CENTER_VERTICAL);return t;
    }
    private EditText input(String hint,String value,int type){
        EditText e=new EditText(this);e.setText(value);e.setHint(hint);
        e.setTextColor(LIGHT);e.setHintTextColor(SUB);e.setTextSize(13);
        e.setInputType(type);e.setSingleLine(true);
        e.setSelectAllOnFocus(true);
        e.setPadding(dp(11),dp(8),dp(11),dp(8));e.setBackground(bg(PANEL));
        e.setMinHeight(dp(45));return e;
    }
    private LinearLayout row(LinearLayout parent){
        LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);
        parent.addView(r,new LinearLayout.LayoutParams(-1,-2));return r;
    }
    private View gap(LinearLayout parent,int h){View v=new View(this);parent.addView(v,new LinearLayout.LayoutParams(1,dp(h)));return v;}
    private void spacerButton(LinearLayout row){View v=new View(this);row.addView(v,new LinearLayout.LayoutParams(0,dp(controlHeight),1));}
    private Button button(LinearLayout parent,String label,int color,int weight,Runnable act){
        Button b=new Button(this);b.setText(label);b.setTextColor(LIGHT);b.setAllCaps(false);
        b.setTextSize(compactDisplay?11:12);b.setGravity(Gravity.CENTER);
        b.setMinHeight(0);b.setMinimumHeight(0);b.setMinWidth(0);b.setMinimumWidth(0);
        b.setBackground(bg(color));
        b.setPadding(dp(1),dp(1),dp(1),dp(1));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(weight==0?-1:0,dp(controlHeight),weight);
        if(parent.getOrientation()==LinearLayout.HORIZONTAL && parent.getChildCount()>0)p.leftMargin=dp(3);
        parent.addView(b,p);b.setOnClickListener(v->act.run());return b;
    }
    private GradientDrawable bg(int col){GradientDrawable d=new GradientDrawable();d.setColor(col);d.setCornerRadius(dp(20));return d;}
    @Override protected void onDestroy(){
        if(appsDialog!=null)appsDialog.dismiss();
        if(settingsDialog!=null)settingsDialog.dismiss();
        stopDiscovery();
        io.execute(()->{if(pairing!=null)pairing.close();if(remote!=null)remote.close();});
        io.shutdown();super.onDestroy();
    }
}
