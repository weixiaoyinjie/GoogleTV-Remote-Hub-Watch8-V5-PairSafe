package com.cecbridge.remotev2;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

/** Distinct Wear OS launcher entry, selectable by a watch-face app shortcut. */
public final class RemotePanelLauncherActivity extends Activity {
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent next = new Intent(this, MainActivity.class);
        next.putExtra(MainActivity.EXTRA_OPEN_PAGE, 0);
        next.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(next);
        finish();
    }
}
