package com.cecbridge.remotev2;

/** Pure geometry shared by rendering and hit testing. No Android dependencies. */
final class RoundPanelGeometry {
    private static final double[] ANGLES={-144,-108,-72,-36,0,36,90,144,180};
    final float cx,cy,screenRadius,wheel,ok,key,orbit;
    final float[] x=new float[ANGLES.length],y=new float[ANGLES.length];

    RoundPanelGeometry(float width,float height,float edgeInset,float gap){
        cx=width*.5f;cy=height*.5f;
        screenRadius=Math.max(0,Math.min(width,height)*.5f-edgeInset);
        wheel=screenRadius*.59f;
        ok=wheel*.47f;
        // Outer tangency: orbit + key = R. Inner clearance: orbit - key = wheel + gap.
        float clearance=Math.min(gap,screenRadius*.20f);
        key=Math.max(0,(screenRadius-wheel-clearance)*.5f);
        orbit=screenRadius-key;
        for(int i=0;i<ANGLES.length;i++){
            double a=Math.toRadians(ANGLES[i]);
            x[i]=cx+orbit*(float)Math.cos(a);
            y[i]=cy+orbit*(float)Math.sin(a);
        }
    }

    int hitKey(float px,float py){
        if(key<=0)return -1;
        for(int i=0;i<x.length;i++){
            float dx=px-x[i],dy=py-y[i];
            if(dx*dx+dy*dy<=key*key)return i;
        }
        return -1;
    }

    // 0: outside, 1: OK, 2: up, 3: down, 4: left, 5: right.
    int hitWheel(float px,float py){
        if(wheel<=0)return 0;
        float dx=px-cx,dy=py-cy,d2=dx*dx+dy*dy;
        if(d2> wheel*wheel)return 0;
        if(d2<=ok*ok)return 1;
        if(Math.abs(dx)>Math.abs(dy))return dx<0?4:5;
        return dy<0?2:3;
    }
}
