# Google TV Remote Hub · Watch8 V5 PairSafe

## 使用方式
- 手表应用列表只注册两个入口：TV 遥控、TV 媒体。分别选择作为表盘快捷方式；打开直接显示对应的单一圆形面板，不可翻至其他页面。按系统返回键退出。
- 遥控面板保留电源、音量、方向、确定、返回、菜单、主页、YouTube、Netflix。
- 媒体面板保留电源、音量、播放/暂停、停止、上一首/下一首、快进/快退、确定、Kodi、Qobuz、方向/播放切换。
- 点击任一面板顶部「设置」打开按需弹窗：连接状态、电源状态、搜索电视、手动 IP、连接、首次配对六位码、忘记配对、Play 启动模式、自定义电视 App 及两个面板的固定快捷方式。自定义 App 可添加、长按修改/删除、点击启动；启动后自动返回控制面板，便于按确定键。
- 不再注册通用第三入口，也不再提供独立电源快捷方式；电源功能保留在两个面板。旧版固定电源快捷方式尝试停用；若启动器仍显示旧图标，请手动删除。
- 此版不依赖手机、不新增手机端。原先没有手机配套源码，保留独立局域网遥控，避免改变连接机制或转移私钥。

## 体积与兼容性
- 去掉六页容器，恢复 V4 原始 Bouncy Castle 1.78.1 依赖、证书、TLS、配对协议及远程连接实现。仅为设置弹窗适配输入框空值和保存的 IP。不主动迁移或清除配对数据。
- 保留 applicationId `com.cecbridge.remotev2.wear`、SharedPreferences `google_tv_remote_v2`、`remote-client.p12`、证书别名及密码；同签名覆盖升级时原有数据应保留。不同 debug 签名无法覆盖；卸载会丢失配对和设置。
- Google TV 的 Play App Link 行为取决于电视，可能仅打开商店详情；手动确认模式可按中央确定键。自动确认可能误触。电源键为 Android keycode 26，不是 HDMI-CEC。

## GitHub 编译（不解压 ZIP）
1. 新建仓库 `GoogleTV-Remote-Hub-Watch8-V5-PairSafe`。
2. 上传 `GoogleTV-Remote-Hub-Watch8-V5-PairSafe-OneUpload.zip` 至仓库根目录。
3. 创建 `.github/workflows/build-apk.yml`，复制附带的同名编译文件内容。
4. Actions → Build Google TV Remote Watch8 V5 PairSafe APK → Run workflow。
5. 下载产物 `GoogleTV-Remote-Hub-Watch8-V5-PairSafe-APK`，其中包含 `watch8-debug.apk`。

## 验证范围
对照本次上传的 V4 源码，IdentityStore.java、PairingClient.java、RemoteSession.java、Proto.java 逐字节一致；原始依赖和配对、连接、发现流程已恢复（仅输入控件空值防护）。未执行完整 Android 编译或真机测试，尚未确认用户曾成功配对的版本是否就是 V4。若不是 V4，应改用已成功的原始版本为基准。APK 不再以删除加密依赖来缩小。
